#!/usr/bin/env bash
# Usage: sudo bash rollback.sh /var/backups/mportal-multiselect/YYYYMMDD-HHMMSS-PID
set -Eeuo pipefail
ROOT=/opt/maintenance-portal-demo
if (( EUID != 0 )); then echo 'ERROR: run as root' >&2; exit 1; fi
BACKUP=${1:?Specify the backup directory printed by install.sh}
[[ -f "$BACKUP/manifest.txt" && -f "$BACKUP/app.py" && -f "$BACKUP/templates/index.html" ]] || { echo 'Invalid backup directory' >&2; exit 1; }
while IFS= read -r rel; do
    case "$rel" in
       app.py|templates/index.html|mportal_batch.py|templates/confirm_batch.html|templates/result_batch.html) ;;
       *) echo "Unexpected manifest entry: $rel" >&2; exit 1 ;;
    esac
    if [[ -f "$BACKUP/$rel" ]]; then
      cp -a "$BACKUP/$rel" "$ROOT/$rel"
    else
      rm -f -- "$ROOT/$rel"
    fi
done < "$BACKUP/manifest.txt"
systemctl restart maintenance-portal
systemctl is-active --quiet maintenance-portal
if [[ -n "${PORTAL_HEALTH_URL:-}" ]]; then
  curl --fail --silent --show-error --location --max-time 15 --retry 3 \
    --retry-connrefused --output /dev/null "$PORTAL_HEALTH_URL"
  printf 'HTTPS healthcheck succeeded: %s\n' "$PORTAL_HEALTH_URL"
else
  echo 'HTTPS healthcheck skipped. Verify the actual site via HTTPS/443.'
fi
echo 'Rollback completed; previous MPortal source restored; systemd service active.'
