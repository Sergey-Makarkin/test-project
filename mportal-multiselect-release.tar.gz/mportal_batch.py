"""One-time, server-side pending confirmations for multi-host Zabbix maintenance.

Does not access Zabbix or Active Directory and never stores login credentials.
"""
import hashlib
import json
import secrets
import sqlite3
import time

from fastapi import HTTPException

MAX_HOSTS = 48
CONFIRM_TTL = 5 * 60


def normalized_host_ids(items):
    """Keep the selection order; reject invalid, duplicate or oversized batches."""
    if not isinstance(items, (list, tuple)) or not 1 <= len(items) <= MAX_HOSTS:
        raise HTTPException(422, f'Select between 1 and {MAX_HOSTS} Windows hosts')
    values = []
    seen = set()
    for item in items:
        if not isinstance(item, str) or not item.isascii() or not item.isdecimal():
            raise HTTPException(422, 'Invalid host ID')
        if item in seen:
            raise HTTPException(422, 'Duplicate Windows host selection')
        seen.add(item)
        values.append(item)
    return values


def ensure_schema(db_path):
    with sqlite3.connect(db_path, timeout=15) as db:
        db.execute('''CREATE TABLE IF NOT EXISTS mp_batch_pending (
            nonce_hash TEXT PRIMARY KEY,
            actor TEXT NOT NULL,
            hosts_json TEXT NOT NULL,
            duration INTEGER NOT NULL,
            reason TEXT NOT NULL,
            start_delay INTEGER NOT NULL,
            expires_at INTEGER NOT NULL
        )''')
        db.execute('CREATE INDEX IF NOT EXISTS mp_batch_pending_expiry ON mp_batch_pending(expires_at)')


def create_pending(db_path, actor, hostids, duration, reason, start_delay):
    hostids = normalized_host_ids(hostids)
    if len(hostids) < 2:
        raise HTTPException(422, 'Batch confirmation requires multiple hosts')
    nonce = secrets.token_urlsafe(32)
    digest = hashlib.sha256(nonce.encode('ascii')).hexdigest()
    with sqlite3.connect(db_path, timeout=15) as db:
        db.execute('DELETE FROM mp_batch_pending WHERE expires_at < ?', (int(time.time()),))
        db.execute('''INSERT INTO mp_batch_pending
                      (nonce_hash,actor,hosts_json,duration,reason,start_delay,expires_at)
                      VALUES (?,?,?,?,?,?,?)''',
                   (digest, actor, json.dumps(hostids), duration, reason, start_delay,
                    int(time.time()) + CONFIRM_TTL))
    return nonce


def consume_pending(db_path, actor, nonce):
    if not isinstance(nonce, str) or not 20 <= len(nonce) <= 200:
        raise HTTPException(409, 'Batch confirmation expired or already used')
    digest = hashlib.sha256(nonce.encode('utf-8')).hexdigest()
    with sqlite3.connect(db_path, timeout=15) as db:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('''SELECT actor,hosts_json,duration,reason,start_delay,expires_at
                            FROM mp_batch_pending WHERE nonce_hash=?''', (digest,)).fetchone()
        if row is None or row[0] != actor or row[5] < int(time.time()):
            raise HTTPException(409, 'Batch confirmation expired or already used')
        db.execute('DELETE FROM mp_batch_pending WHERE nonce_hash=?', (digest,))
    return {
        'host_ids': normalized_host_ids(json.loads(row[1])),
        'duration': int(row[2]), 'reason': row[3], 'start_delay': int(row[4]),
    }
