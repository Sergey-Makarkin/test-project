"""Windows Maintenance Portal with tightly scoped live maintenance testing."""
import hmac
import json
import os
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from fastapi.staticfiles import StaticFiles

from fastapi import FastAPI, Request as HttpRequest, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from ad_auth import authenticate
import project_access
import mportal_batch
import project_admin
import alert_settings
import alert_admin
from portal_auth import (
    ensure_tables, log_auth, create_session, session_from_request,
    delete_session, create_pending, consume_pending, is_login_blocked,
    record_login_failure, clear_login_failures, COOKIE, TTL,
)

BASE = Path(__file__).resolve().parent
DB = Path(os.environ.get(
    "PORTAL_DB_PATH",
    str(BASE / "audit_demo.sqlite3")
))
ensure_tables(DB)
project_access.ensure_schema(DB)
mportal_batch.ensure_schema(DB)
alert_settings.ensure_schema(DB)
project_access.refuse_unsafe_disable(DB)
app = FastAPI(title='Windows Maintenance Portal')
app.mount(
    "/static",
    StaticFiles(directory=str(BASE / "static")),
    name="static"
)
templates = Jinja2Templates(directory=str(BASE / 'templates'))
templates.env.globals["live_mode"] = (
    os.getenv("PORTAL_LIVE_WRITES", "0") == "1"
)
LOGIN_CSRF_COOKIE = 'mp_login_csrf'
# Local SSH tunnel: 0. For HTTPS reverse proxy: 1.
SECURE_COOKIES = os.getenv('PORTAL_SECURE_COOKIE', '0') == '1'


def db_connect():
    conn = sqlite3.connect(DB, timeout=10)
    conn.execute('''CREATE TABLE IF NOT EXISTS audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL, actor TEXT NOT NULL,
        action TEXT NOT NULL, host_id TEXT NOT NULL,
        duration_minutes INTEGER NOT NULL, reason TEXT NOT NULL,
        outcome TEXT NOT NULL, request_id TEXT NOT NULL,
        zabbix_maintenance_id TEXT
    )''')
    return conn


def audit(actor, action, host_id, duration, reason, outcome, request_id, maintenance_id=None):
    with db_connect() as db:
        db.execute('''INSERT INTO audit
            (created_at,actor,action,host_id,duration_minutes,reason,outcome,request_id,zabbix_maintenance_id)
            VALUES (?,?,?,?,?,?,?,?,?)''',
            (datetime.now(timezone.utc).isoformat(), actor, action, host_id,
             duration, reason, outcome, request_id, maintenance_id))


def identity(request):
    return project_access.identity(DB, request, session_from_request)


def csrf(request):
    return identity(request)['csrf']


def check_csrf(request, submitted):
    expected = csrf(request)
    if not submitted or not hmac.compare_digest(expected, submitted):
        raise HTTPException(403, 'CSRF validation failed')


@app.get('/login', response_class=HTMLResponse)
def login_get(request: HttpRequest):
    token = secrets.token_urlsafe(32)
    response = templates.TemplateResponse(request, 'login.html', {'csrf': token, 'error': None})
    response.set_cookie(LOGIN_CSRF_COOKIE, token, httponly=True,
                        secure=SECURE_COOKIES, samesite='strict', max_age=600)
    return response


@app.post('/login')
def login_post(request: HttpRequest, username: str = Form(...),
               password: str = Form(...), csrf_token: str = Form(...)):
    expected = request.cookies.get(LOGIN_CSRF_COOKIE, '')
    if not expected or not hmac.compare_digest(expected, csrf_token):
        raise HTTPException(403, 'Login CSRF validation failed')
    username = username.strip()
    if not username or len(username) > 180:
        raise HTTPException(400, 'Invalid login')
    if is_login_blocked(DB, username):
        log_auth(DB, 'login', username, 'RATE_LIMITED')
        raise HTTPException(429, 'Too many login attempts. Try again later.')
    try:
        result = authenticate(username, password)
    except Exception:
        log_auth(DB, 'login', username, 'ERROR')
        raise HTTPException(503, 'Directory authentication temporarily unavailable')
    if not result.authenticated:
        record_login_failure(DB, username)
        log_auth(DB, 'login', username, 'DENIED')
        raise HTTPException(401, 'Invalid credentials or insufficient group membership')
    if project_access.enabled():
        try:
            role = project_access.live_rights(DB, username)['role']
        except HTTPException as exc:
            if exc.status_code == 403:
                record_login_failure(DB, username)
                log_auth(DB, 'login', username, 'DENIED')
                raise HTTPException(401, 'Invalid credentials or insufficient group membership')
            log_auth(DB, 'login', username, 'ERROR')
            raise
    else:
        if not result.authorized:
            record_login_failure(DB, username)
            log_auth(DB, 'login', username, 'DENIED')
            raise HTTPException(401, 'Invalid credentials or insufficient group membership')
        role = result.role
    clear_login_failures(DB, username)
    token = create_session(DB, username, role)
    log_auth(DB, 'login', username, 'SUCCESS')
    response = RedirectResponse('/', status_code=303)
    response.set_cookie(COOKIE, token, httponly=True, secure=SECURE_COOKIES,
                        samesite='strict', max_age=TTL)
    response.delete_cookie(LOGIN_CSRF_COOKIE)
    return response


@app.post('/logout')
def logout(request: HttpRequest, csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    actor = identity(request)['name']
    delete_session(DB, request)
    log_auth(DB, 'logout', actor, 'SUCCESS')
    response = RedirectResponse('/login', status_code=303)
    response.delete_cookie(COOKIE)
    return response


def allowed_hosts():
    """Read live Windows hosts, fail closed if Zabbix is not configured."""
    api_url = os.getenv('ZABBIX_API_URL', '').strip()
    token = os.getenv('ZABBIX_API_TOKEN', '').strip()
    if not api_url or not token:
        raise HTTPException(503, 'Zabbix API is not configured')
    if not (api_url.startswith('http://127.0.0.1/') or api_url.startswith('https://')):
        raise HTTPException(503, 'Zabbix API must use HTTPS or localhost')
    data = json.dumps({
        'jsonrpc': '2.0', 'method': 'host.get', 'id': 1,
        'params': {
            'templateids': ['10081'],
            'output': ['hostid', 'name', 'status', 'maintenance_status'],
            'selectParentTemplates': ['templateid']
        }
    }).encode()
    req = Request(api_url, data=data, headers={
        'Content-Type': 'application/json-rpc',
        'Authorization': f'Bearer {token}'
    })
    try:
        with urlopen(req, timeout=15) as response:
            result = json.load(response)
    except Exception as exc:
        raise HTTPException(503, 'Unable to read hosts from Zabbix API') from exc
    if 'error' in result or not isinstance(result.get('result'), list):
        raise HTTPException(503, 'Zabbix API host.get failed')
    windows = {}
    for host in result['result']:
        if host.get('status') != '0':
            continue
        if any(t.get('templateid') == '10081'
               for t in host.get('parentTemplates', [])):
            windows[host['hostid']] = {
                'hostid': host['hostid'], 'name': host['name'],
                'status': host['status'],
                'maintenance': host.get('maintenance_status', '0')
            }
    return windows


def visible_hosts(user):
    """Enforce project scoping for every list, review and execute endpoint."""
    return project_access.filter_hosts(DB, user, allowed_hosts())


def validate(user, host_id, duration, reason, hosts, start_delay=0):
    if user['role'] not in {'operator', 'admin'}:
        raise HTTPException(403, 'Insufficient role (Operator required)')
    if host_id not in hosts:
        raise HTTPException(403, 'Host outside allowed Windows scope')
    if duration not in (30, 60, 120, 240):
        raise HTTPException(422, 'Invalid duration')
    if start_delay not in (0, 30, 60, 120, 240):
        raise HTTPException(422, 'Invalid scheduled start delay')
    if not 5 <= len(reason.strip()) <= 200:
        raise HTTPException(422, 'Reason must contain 5 to 200 characters')


def payload(host_id, duration, reason, actor, start_delay=0, now=None):
    now = now or datetime.now(timezone.utc)
    start = int(now.timestamp()) + (start_delay * 60 if start_delay else 5)
    seconds = duration * 60
    return {
        'name': f'PORTAL-{host_id}-{start}',
        'description': f'Actor: {actor}; Reason: {reason}',
        'maintenance_type': 0,
        'active_since': start,
        'active_till': start + seconds,
        'hosts': [{'hostid': host_id}],
        'timeperiods': [{'timeperiod_type': 0, 'start_date': start, 'period': seconds}]
    }


def api_call(method, params):
    api_url = os.getenv('ZABBIX_API_URL', '').strip()
    token = os.getenv('ZABBIX_API_TOKEN', '').strip()
    if not token or not api_url.startswith('http://127.0.0.1/'):
        raise HTTPException(503, 'Local Zabbix API is not configured')
    req = Request(api_url, data=json.dumps({
        'jsonrpc': '2.0', 'method': method, 'params': params, 'id': 1
    }).encode('utf-8'), headers={
        'Content-Type': 'application/json-rpc',
        'Authorization': f'Bearer {token}',
    })
    try:
        with urlopen(req, timeout=20) as response:
            result = json.load(response)
    except Exception as exc:
        raise HTTPException(502, f'Zabbix API transport failed ({method})') from exc
    if 'error' in result or 'result' not in result:
        raise HTTPException(502, f'Zabbix API rejected {method}; inspect server logs')
    return result['result']


def is_live_test(user, host_id, duration):
    """Production write gate: approved AD roles and enabled Windows scope only."""
    return (
        os.getenv('PORTAL_LIVE_WRITES', '0') == '1'
        and user['role'] in {'admin', 'operator'}
        and duration in (30, 60, 120, 240)
        and host_id in visible_hosts(user)
    )


def zabbix_create(params, *, live=False, user=None):
    if not live:
        return {'dry_run': True, 'payload': params}
    host_id = params['hosts'][0]['hostid']
    if (os.getenv('PORTAL_LIVE_WRITES', '0') != '1'
            or host_id not in allowed_hosts()
            or (project_access.enabled() and (user is None or host_id not in visible_hosts(user)))
            or int(params['timeperiods'][0]['period']) not in (1800, 3600, 7200, 14400)):
        raise HTTPException(403, 'Live maintenance is not authorized for this Windows host')
    # Abort if this host is already in an active maintenance.
    existing = api_call('maintenance.get', {
        'hostids': [host_id],
        'output': ['maintenanceid', 'active_since', 'active_till'],
        'selectTimeperiods': 'extend',
    })
    proposed_start = int(params['active_since'])
    proposed_end = int(params['active_till'])
    for m in existing:
        for period in m.get('timeperiods', []):
            if str(period.get('timeperiod_type')) != '0':
                # Do not automatically override potentially recurring maintenance.
                raise HTTPException(409, 'Another recurring maintenance exists for this host; review in Zabbix')
            interval_start = int(period.get('start_date', m['active_since']))
            interval_end = interval_start + int(period.get('period', 0))
            if proposed_start < interval_end and interval_start < proposed_end:
                raise HTTPException(409, 'Overlapping maintenance already exists for this host')
    result = api_call('maintenance.create', params)
    ids = result.get('maintenanceids', [])
    if len(ids) != 1:
        raise HTTPException(502, 'Unexpected maintenance.create response')
    return {'dry_run': False, 'maintenance_id': ids[0], 'payload': params}


def owned_maintenance(hosts):
    """List ONLY Zabbix maintenance objects created by this portal and linked to one allowed host."""
    with db_connect() as db:
        ids = [r[0] for r in db.execute(
            "SELECT DISTINCT zabbix_maintenance_id FROM audit "
            "WHERE outcome='CREATED' AND zabbix_maintenance_id IS NOT NULL"
        ).fetchall()]
    if not ids:
        return []
    found = []
    for offset in range(0, len(ids), 100):
        found.extend(api_call('maintenance.get', {
            'maintenanceids': ids[offset:offset+100],
            'output': ['maintenanceid', 'name', 'maintenance_type', 'active_since', 'active_till'],
            'selectHosts': ['hostid'],
            'selectTimeperiods': 'extend',
        }))
    now = int(datetime.now(timezone.utc).timestamp())
    rows = []
    for m in found:
        hostids = [h['hostid'] for h in m.get('hosts', [])]
        # Do not manage a system maintenance or a maintenance shared with other hosts.
        if len(hostids) != 1 or hostids[0] not in hosts:
            continue
        # Only one-time maintenance that follows the schema created by this portal.
        periods = m.get('timeperiods', [])
        if len(periods) != 1 or str(periods[0].get('timeperiod_type')) != '0':
            continue
        start, end = int(m['active_since']), int(m['active_till'])
        rows.append({
            'id': m['maintenanceid'], 'host_id': hostids[0],
            'host_name': hosts[hostids[0]]['name'],
            'start': start, 'end': end, 'remaining_minutes': max(0, (end-now+59)//60),
        'start_utc': datetime.fromtimestamp(start, timezone.utc).strftime('%Y-%m-%d %H:%M UTC'),
            'active': start <= now < end,
            'expired': end <= now,
            'period': periods[0],
        })
    return sorted(rows, key=lambda m: m['end'])


def allow_live_manage(user, maintenance):
    """Allow writes only for AD Operator/Admin on a currently approved Windows host."""
    if (user['role'] not in {'admin', 'operator'}
            or os.getenv('PORTAL_LIVE_WRITES', '0') != '1'
            or maintenance['host_id'] not in visible_hosts(user)):
        raise HTTPException(403, 'Live management is not authorized')


def management_operation(user, action, maintenance, minutes=0):
    allow_live_manage(user, maintenance)
    now = int(datetime.now(timezone.utc).timestamp())
    if action == 'stop':
        if maintenance['expired']:
            raise HTTPException(409, 'Maintenance has already expired')
        result = api_call('maintenance.delete', [maintenance['id']])
        if str(maintenance['id']) not in [str(i) for i in result.get('maintenanceids', [])]:
            raise HTTPException(502, 'Unexpected Zabbix maintenance.delete result')
    elif action == 'extend':
        if not maintenance['active'] or minutes not in (30, 60):
            raise HTTPException(409, 'Only active maintenance may be extended by 30 or 60 minutes')
        new_end = maintenance['end'] + 60 * minutes
        start = maintenance['start']
        # Limit total maintenance time to 4h during validation.
        if new_end - start > 4 * 3600:
            raise HTTPException(422, 'Maintenance may not exceed 4 hours')
        data = {
            'maintenanceid': maintenance['id'],
            'active_till': new_end,
            'timeperiods': [{
                'timeperiod_type': 0, 'start_date': start,
                'period': new_end - start,
            }]
        }
        result = api_call('maintenance.update', data)
        if str(maintenance['id']) not in [str(i) for i in result.get('maintenanceids', [])]:
            raise HTTPException(502, 'Unexpected Zabbix maintenance.update result')
    elif action == 'cleanup':
        if not maintenance['expired']:
            raise HTTPException(409, 'Only expired maintenance may be cleaned up')
        result = api_call('maintenance.delete', [maintenance['id']])
        if str(maintenance['id']) not in [str(i) for i in result.get('maintenanceids', [])]:
            raise HTTPException(502, 'Unexpected Zabbix maintenance.delete result')
    else:
        raise HTTPException(422, 'Unsupported maintenance action')
    audit(user['name'], 'maintenance.'+action, maintenance['host_id'], minutes,
          'Portal maintenance management', 'SUCCESS', secrets.token_hex(10), maintenance['id'])


@app.get('/', response_class=HTMLResponse)
def index(request: HttpRequest):
    try:
        user = identity(request)
    except HTTPException as exc:
        if exc.status_code == 401:
            return RedirectResponse('/login', status_code=303)
        raise
    hosts = visible_hosts(user)
    maintenances = owned_maintenance(hosts)
    with db_connect() as db:
        if user['scope'] == 'admin' or not project_access.enabled():
            rows = db.execute("""SELECT created_at,actor,host_id,duration_minutes,outcome,request_id
                                 FROM audit ORDER BY id DESC LIMIT 10""").fetchall()
        elif hosts:
            host_ids = list(hosts)
            placeholders = ','.join('?' for _ in host_ids)
            rows = db.execute(
                f"""SELECT created_at,actor,host_id,duration_minutes,outcome,request_id
                     FROM audit WHERE host_id IN ({placeholders}) ORDER BY id DESC LIMIT 10""",
                host_ids).fetchall()
        else:
            rows = []
    in_maintenance = sum(str(h['maintenance']) == '1' for h in hosts.values())
    return templates.TemplateResponse(request, 'index.html', {
        'user': user, 'hosts': sorted(hosts.values(), key=lambda h: h['name'].lower()),
        'csrf': csrf(request), 'rows': rows, 'dry_run': True,
        'total_hosts': len(hosts), 'maintenance_hosts': in_maintenance,
        'available_hosts': len(hosts) - in_maintenance,
        'maintenances': maintenances,
        'live_management': user['role'] in {'admin', 'operator'} and os.getenv('PORTAL_LIVE_WRITES') == '1',
    })


@app.post('/maintenance/review', response_class=HTMLResponse)
def maintenance_review(request: HttpRequest, maintenance_id: str = Form(...),
                       action: str = Form(...), minutes: int = Form(0),
                       csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    user = identity(request)
    if action not in ('stop', 'extend', 'cleanup'):
        raise HTTPException(422, 'Unknown action')
    hosts = visible_hosts(user)
    candidates = [m for m in owned_maintenance(hosts) if m['id'] == maintenance_id]
    if len(candidates) != 1:
        raise HTTPException(404, 'Portal maintenance not found')
    m = candidates[0]
    allow_live_manage(user, m)
    if action == 'extend' and minutes not in (30, 60):
        raise HTTPException(422, 'Invalid extension')
    if action == 'stop' and m['expired']:
        raise HTTPException(409, 'Maintenance has already expired')
    if action == 'extend' and (not m['active'] or m['end']-m['start']+minutes*60 > 14400):
        raise HTTPException(409, 'Maintenance cannot be extended')
    if action == 'cleanup' and not m['expired']:
        raise HTTPException(409, 'Maintenance is not expired')
    # Reuse existing atomic, one-time pending store with a scoped action identifier.
    action_key = f'@manage:{action}:{maintenance_id}:{minutes}'
    nonce = create_pending(DB, request, action_key, 30, 'Portal maintenance management')
    return templates.TemplateResponse(request, 'manage_confirm.html', {
        'user': user, 'csrf': csrf(request), 'nonce': nonce,
        'action': action, 'minutes': minutes, 'maintenance': m,
    })


@app.post('/maintenance/execute')
def maintenance_execute(request: HttpRequest, nonce: str = Form(...),
                        csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    user = identity(request)
    if user['role'] not in {'admin', 'operator'}:
        raise HTTPException(403, 'Operator or Admin role required')
    intent = consume_pending(DB, request, nonce)
    import re
    match = re.fullmatch(r'@manage:(stop|extend|cleanup):([0-9]+):(0|30|60)', intent['host_id'])
    if not match:
        raise HTTPException(409, 'Invalid management confirmation')
    action, maintenance_id, minutes_str = match.groups()
    minutes = int(minutes_str)
    if ((action == 'extend' and minutes not in (30, 60)) or
            (action != 'extend' and minutes != 0)):
        raise HTTPException(422, 'Invalid extension')
    hosts = visible_hosts(user)
    candidates = [m for m in owned_maintenance(hosts) if m['id'] == maintenance_id]
    if len(candidates) != 1:
        raise HTTPException(404, 'Portal maintenance not found')
    m = candidates[0]
    allow_live_manage(user, m)
    try:
        management_operation(user, action, m, minutes)
    except Exception:
        audit(user['name'], 'maintenance.'+action, m['host_id'], minutes,
              'Portal maintenance management', 'ERROR', secrets.token_hex(10), maintenance_id)
        raise
    return RedirectResponse('/', status_code=303)


def validate_host_selection(user, host_ids, duration, reason, hosts, start_delay):
    """Validate every host against current live AD/project/Zabbix scope."""
    host_ids = mportal_batch.normalized_host_ids(host_ids)
    for host_id in host_ids:
        validate(user, host_id, duration, reason, hosts, start_delay)
    return host_ids


def preflight_batch_overlaps(params_by_host):
    """Check all requested hosts before creating any maintenance object."""
    for host_id, params in params_by_host:
        existing = api_call('maintenance.get', {
            'hostids': [host_id],
            'output': ['maintenanceid', 'active_since', 'active_till'],
            'selectTimeperiods': 'extend',
        })
        requested_start = int(params['active_since'])
        requested_end = int(params['active_till'])
        for entry in existing:
            for period in entry.get('timeperiods', []):
                if str(period.get('timeperiod_type')) != '0':
                    raise HTTPException(409, f'Host {host_id}: recurring maintenance exists; review in Zabbix')
                period_start = int(period.get('start_date', entry['active_since']))
                period_end = period_start + int(period.get('period', 0))
                if requested_start < period_end and period_start < requested_end:
                    raise HTTPException(409, f'Host {host_id}: overlapping maintenance already exists')


@app.post('/confirm', response_class=HTMLResponse)
def confirm(request: HttpRequest, host_id: list[str] = Form(...), duration: int = Form(...),
            reason: str = Form(...), start_delay: int = Form(0), csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    user = identity(request)
    hosts = visible_hosts(user)
    selected = validate_host_selection(user, host_id, duration, reason, hosts, start_delay)
    if len(selected) > 1:
        nonce = mportal_batch.create_pending(DB, user['name'], selected, duration,
                                             reason.strip(), start_delay)
        intent = {'host_ids': selected, 'duration': duration, 'reason': reason.strip(),
                  'start_delay': start_delay, 'nonce': nonce}
        live = os.getenv('PORTAL_LIVE_WRITES', '0') == '1'
        return templates.TemplateResponse(request, 'confirm_batch.html', {
            'intent': intent, 'selected_hosts': [hosts[hid] for hid in selected],
            'user': user, 'csrf': csrf(request), 'live_test': live
        })
    host_id = selected[0]
    nonce = create_pending(DB, request, host_id, duration, reason.strip(), start_delay)
    intent = {'host_id': host_id, 'duration': duration, 'reason': reason.strip(),
              'start_delay': start_delay, 'nonce': nonce}
    return templates.TemplateResponse(request, 'confirm.html', {
        'intent': intent, 'host': hosts[host_id], 'user': user, 'csrf': csrf(request),
        'live_test': is_live_test(user, host_id, duration)
    })


@app.post('/execute', response_class=HTMLResponse)
def execute(request: HttpRequest, nonce: str = Form(...), csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    user = identity(request)
    # Fail viewer/admin check before consuming confirmation.
    if user['role'] not in {'operator', 'admin'}:
        raise HTTPException(403, 'Insufficient role')
    intent = consume_pending(DB, request, nonce)
    host_id, duration, reason = intent['host_id'], intent['duration'], intent['reason']
    start_delay = intent['start_delay']
    hosts = visible_hosts(user)
    validate(user, host_id, duration, reason, hosts, start_delay)
    request_id = secrets.token_hex(10)
    params = payload(host_id, duration, reason, user['name'], start_delay)
    live = is_live_test(user, host_id, duration)
    try:
        result = zabbix_create(params, live=live, user=user)
    except HTTPException:
        audit(user['name'], 'maintenance.create', host_id, duration, reason, 'ERROR', request_id)
        raise
    except Exception:
        audit(user['name'], 'maintenance.create', host_id, duration, reason, 'ERROR', request_id)
        raise HTTPException(502, 'Maintenance operation failed')
    outcome = 'CREATED' if live else 'DRY_RUN'
    audit_reason = f'[start_delay={start_delay}m] {reason}'
    audit(user['name'], 'maintenance.create', host_id, duration, audit_reason, outcome,
          request_id, result.get('maintenance_id'))
    return templates.TemplateResponse(request, 'result.html', {
        'result': result, 'host': hosts[host_id], 'duration': duration,
        'reason': reason, 'outcome': outcome, 'request_id': request_id
    })


@app.post('/execute-batch', response_class=HTMLResponse)
def execute_batch(request: HttpRequest, nonce: str = Form(...), csrf_token: str = Form(...)):
    check_csrf(request, csrf_token)
    user = identity(request)
    if user['role'] not in {'operator', 'admin'}:
        raise HTTPException(403, 'Insufficient role')
    intent = mportal_batch.consume_pending(DB, user['name'], nonce)
    selected = intent['host_ids']
    duration, reason, start_delay = (intent['duration'], intent['reason'], intent['start_delay'])
    hosts = visible_hosts(user)
    validate_host_selection(user, selected, duration, reason, hosts, start_delay)
    # Immediate batch starts shortly after confirmation, not halfway through
    # ten sequential Zabbix API requests. Other start delays are unchanged.
    from datetime import timedelta
    batch_now = datetime.now(timezone.utc)
    if start_delay == 0:
        batch_now += timedelta(seconds=60)
    planned = [(hid, payload(hid, duration, reason, user['name'], start_delay,
                            now=batch_now)) for hid in selected]
    live = os.getenv('PORTAL_LIVE_WRITES', '0') == '1'
    request_id = secrets.token_hex(10)
    results = []
    audit_reason = f'[start_delay={start_delay}m][batch={request_id}] {reason}'

    if live:
        # Validate all hosts against fresh permissions and detect overlaps BEFORE any writes.
        preflight_batch_overlaps(planned)

    for index, (hid, params) in enumerate(planned):
        try:
            response = zabbix_create(params, live=live, user=user)
            outcome = 'CREATED' if live else 'DRY_RUN'
            audit(user['name'], 'maintenance.create', hid, duration, audit_reason,
                  outcome, request_id, response.get('maintenance_id'))
            results.append({'host': hosts[hid], 'status': outcome, 'result': response})
        except Exception as exc:
            # Fail closed for the remainder. Successful earlier hosts remain
            # separately manageable through the existing Portal Maintenance UI.
            audit(user['name'], 'maintenance.create', hid, duration, audit_reason,
                  'ERROR', request_id)
            message = (str(exc.detail) if isinstance(exc, HTTPException)
                       else 'Zabbix API error; verify this host in Zabbix before retrying')
            results.append({'host': hosts[hid], 'status': 'ERROR', 'error': message})
            for skipped_id, _ in planned[index + 1:]:
                results.append({'host': hosts[skipped_id], 'status': 'SKIPPED',
                                'error': 'Stopped after previous error'})
            break

    created = sum(row['status'] == 'CREATED' for row in results)
    failures = sum(row['status'] == 'ERROR' for row in results)
    outcome = ('DRY_RUN' if not live and not failures else
               'CREATED' if live and created == len(selected) else
               'PARTIAL' if created else 'FAILED')
    return templates.TemplateResponse(request, 'result_batch.html', {
        'results': results, 'outcome': outcome, 'duration': duration, 'reason': reason,
        'request_id': request_id, 'start_delay': start_delay,
    })


# Additional administration endpoints. Existing Maintenance routes remain unchanged.
project_admin.install_admin_routes(
    app, DB, templates, identity, check_csrf, allowed_hosts
)

# Email alerting settings are admin-only, with no mail delivery or Zabbix writes.
alert_admin.install_alert_admin_routes(
    app, DB, templates, identity, check_csrf, allowed_hosts
)
