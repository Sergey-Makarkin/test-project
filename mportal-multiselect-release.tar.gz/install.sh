#!/usr/bin/env bash
# Run as root on ml2zbx01. Fails closed if app.py/index.html changed since export.
set -Eeuo pipefail
ROOT=/opt/maintenance-portal-demo
HERE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
APP_SHA=012a47a51ebb031ccaaeb43d44c7263ea528d0bb17693b6b0af49b283917ac8c
INDEX_SHA=f982f2357e40bf5ba0a7444150ca6a6980b46a601c0657d606443b1859285951
if (( EUID != 0 )); then echo 'ERROR: run with sudo' >&2; exit 1; fi
[[ -f "$ROOT/app.py" && -f "$ROOT/templates/index.html" && -x "$ROOT/.venv/bin/python" ]] || { echo 'ERROR: expected MPortal files not found' >&2; exit 1; }
[[ $(sha256sum "$ROOT/app.py" | cut -d' ' -f1) == "$APP_SHA" ]] || { echo 'ERROR: deployed app.py differs from exported version; DO NOT overwrite' >&2; exit 1; }
[[ $(sha256sum "$ROOT/templates/index.html" | cut -d' ' -f1) == "$INDEX_SHA" ]] || { echo 'ERROR: deployed index.html differs from exported version; DO NOT overwrite' >&2; exit 1; }

"$ROOT/.venv/bin/python" -m py_compile "$HERE/app.py" "$HERE/mportal_batch.py"
"$ROOT/.venv/bin/python" - "$HERE/templates" <<'PY'
import sys
from pathlib import Path
from jinja2 import Environment
for p in Path(sys.argv[1]).glob('*.html'):
    Environment().parse(p.read_text())
    print('Template syntax OK:',p.name)
PY

BACKUP="/var/backups/mportal-multiselect/$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$BACKUP/templates"
chmod 0700 "$BACKUP"
cp -a "$ROOT/app.py" "$BACKUP/app.py"
cp -a "$ROOT/templates/index.html" "$BACKUP/templates/index.html"

for name in mportal_batch.py templates/confirm_batch.html templates/result_batch.html; do
   mkdir -p "$BACKUP/$(dirname "$name")"
   if [[ -e "$ROOT/$name" ]]; then cp -a "$ROOT/$name" "$BACKUP/$name"; fi
done

printf '%s\n' 'app.py' 'templates/index.html' 'mportal_batch.py' 'templates/confirm_batch.html' 'templates/result_batch.html' > "$BACKUP/manifest.txt"

deploy_file() {
  local rel="$1" target="$ROOT/$rel" temp
  temp=$(mktemp "$target.multiselect.XXXXXXXX")
  cp "$HERE/$rel" "$temp"
  if [[ -e "$target" ]]; then
    chown --reference="$target" "$temp"
    chmod --reference="$target" "$temp"
  else
    chmod 0644 "$temp"
    chown root:root "$temp"
  fi
  mv -f "$temp" "$target"
}
rollback_on_error() {
  echo 'ERROR: deploy failed, reverting source files...' >&2
  bash "$HERE/rollback.sh" "$BACKUP" || true
}
trap rollback_on_error ERR

deploy_file mportal_batch.py
deploy_file templates/confirm_batch.html
deploy_file templates/result_batch.html
deploy_file templates/index.html
deploy_file app.py

systemctl restart maintenance-portal
systemctl is-active --quiet maintenance-portal
curl --silent --show-error --fail --max-time 10 --output /dev/null 'http://127.0.0.1:8080/login'
trap - ERR
printf '\nSUCCESS: MPortal multiselect installed and /login responded 200.\nBACKUP: %s\n' "$BACKUP"
echo 'Test a SINGLE-host DRY RUN and then a multi-host DRY RUN before any live batch.'
