"""Offline integration tests. No AD, real SMTP, or Zabbix requests."""
import importlib.util
import os
import re
import shutil
import sqlite3
import sys
import types
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from fastapi import HTTPException

SRC = Path(__file__).resolve().parents[1]


def stub_module(name, **attrs):
    module = types.ModuleType(name)
    module.__dict__.update(attrs)
    sys.modules[name] = module
    return module


@pytest.fixture
def portal(tmp_path, monkeypatch):
    shutil.copy(SRC / 'app.py', tmp_path / 'app.py')
    shutil.copy(SRC / 'mportal_batch.py', tmp_path / 'mportal_batch.py')
    shutil.copytree(SRC / 'templates', tmp_path / 'templates')
    # The release deliberately does not replace legacy templates.
    (tmp_path / 'templates' / 'confirm.html').write_text('''{% extends 'base.html' %}
    {% block content %}<p>Server: {{ host.name }}</p>
    <form method="post" action="/execute"></form>{% endblock %}''')
    (tmp_path / 'templates' / 'base.html').write_text('{% block content %}{% endblock %}')
    (tmp_path / 'static').mkdir()
    monkeypatch.syspath_prepend(str(tmp_path))
    monkeypatch.setenv('PORTAL_DB_PATH', str(tmp_path / 'demo.sqlite3'))
    monkeypatch.setenv('PORTAL_LIVE_WRITES', '1')
    monkeypatch.setenv('PORTAL_PROJECT_RBAC', '1')

    state = {'user': {'name': 'operator@example.com', 'role': 'operator', 'scope': 'general', 'csrf': 'csrf-ok'},
             'hosts': {str(i): {'hostid':str(i),'name':f'WIN-{i:02}', 'status':'0','maintenance':'0'}
                       for i in range(101, 113)},
             'requests': [], 'maintenanceid': 1000, 'error_host': None,
             'overlap_host': None}

    def identity(db, request, reader):
        return state['user']

    def filtered(db, user, hosts):
        if user['role'] == 'viewer':
            return hosts
        return {hid: val for hid, val in hosts.items() if hid not in {'112'}}

    stub_module('ad_auth', authenticate=lambda *a, **kw: None)
    stub_module('project_access', ensure_schema=lambda _:None, refuse_unsafe_disable=lambda _:None,
                identity=identity, enabled=lambda:True, filter_hosts=filtered)
    stub_module('project_admin', install_admin_routes=lambda *a, **kw:None)
    stub_module('alert_settings', ensure_schema=lambda _:None)
    stub_module('alert_admin', install_alert_admin_routes=lambda *a, **kw:None)
    stub_module('portal_auth', ensure_tables=lambda _:None, log_auth=lambda *a:None,
                create_session=lambda *a:'token',session_from_request=lambda *a:None,
                delete_session=lambda *a:None,create_pending=lambda *a:'single-token',
                consume_pending=lambda *a:None,is_login_blocked=lambda *a:False,
                record_login_failure=lambda *a:None,clear_login_failures=lambda *a:None,
                COOKIE='cookie',TTL=600)

    spec = importlib.util.spec_from_file_location('batch_portal_app',tmp_path/'app.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    monkeypatch.setattr(mod,'allowed_hosts',lambda:state['hosts'])

    def api_call(method, params):
        if method=='maintenance.get':
            if params['hostids'][0] == state['overlap_host']:
                return [{'active_since':params.get('start',0),'timeperiods':[
                    {'timeperiod_type':1}]}]
            return []
        if method=='maintenance.create':
            hid=params['hosts'][0]['hostid']
            if hid == state['error_host']:
                raise HTTPException(502, 'Simulated Zabbix failure')
            state['requests'].append(params)
            state['maintenanceid']+=1
            return {'maintenanceids':[str(state['maintenanceid'])]}
        raise ValueError(method)

    monkeypatch.setattr(mod,'api_call',api_call)
    client=TestClient(mod.app, raise_server_exceptions=True)
    yield mod, client, state, tmp_path
    client.close()
    for name in ('ad_auth','project_access','project_admin','alert_settings','alert_admin','portal_auth'):
        sys.modules.pop(name,None)
    sys.modules.pop('mportal_batch',None)


def request_confirm(client, hostids):
    return client.post('/confirm', data={'host_id':hostids,'duration':'120',
                          'reason':'Windows updates','start_delay':'0','csrf_token':'csrf-ok'})


def get_nonce(html):
    return re.search(r'name="nonce" value="([^"]+)"',html).group(1)


def execute(client, nonce):
    return client.post('/execute-batch',data={'nonce':nonce,'csrf_token':'csrf-ok'})


def test_dryrun_multiple_no_writes(portal, monkeypatch):
    mod,client,state,_=portal
    monkeypatch.setenv('PORTAL_LIVE_WRITES','0')
    r=request_confirm(client,['101','102','103'])
    assert r.status_code == 200
    assert '3 Windows hosts' in r.text
    result=execute(client,get_nonce(r.text))
    assert result.status_code == 200 and 'DRY_RUN' in result.text
    assert not state['requests']


def test_live_batch_individual_maintenance_and_audit(portal):
    mod,client,state,tmp=portal
    hosts=[str(x) for x in range(101,111)]
    confirm=request_confirm(client,hosts)
    assert confirm.status_code == 200 and '10 Windows hosts' in confirm.text
    result=execute(client,get_nonce(confirm.text))
    assert result.status_code == 200
    assert 'Batch Maintenance: CREATED' in result.text
    assert len(state['requests']) == 10
    assert all(len(req['hosts'])==1 for req in state['requests'])
    assert set(req['hosts'][0]['hostid'] for req in state['requests'])==set(hosts)
    assert len({req['active_since'] for req in state['requests']}) == 1
    assert len({req['active_till'] for req in state['requests']}) == 1
    with sqlite3.connect(tmp/'demo.sqlite3') as db:
        audit = db.execute('SELECT host_id, request_id, outcome FROM audit').fetchall()
    assert len(audit)==10 and len(set(row[1] for row in audit))==1
    assert all(x[2]=='CREATED' for x in audit)
    replay=execute(client,get_nonce(confirm.text))
    assert replay.status_code==409
    assert len(state['requests'])==10


def test_one_host_uses_original_confirm_route(portal):
    mod,client,state,_=portal
    r=request_confirm(client,['101'])
    assert r.status_code == 200
    assert 'Server:' in r.text
    assert 'execute-batch' not in r.text


def test_invalid_and_duplicate_hosts_denied(portal):
    mod,client,state,_=portal
    assert request_confirm(client,['101','101']).status_code == 422
    assert request_confirm(client,['101','112']).status_code == 403
    assert request_confirm(client,['101','999']).status_code == 403
    assert request_confirm(client,['101','bad']).status_code == 422
    assert request_confirm(client,[]).status_code == 422


def test_lost_permission_between_confirm_and_execute(portal):
    mod,client,state,_=portal
    confirm=request_confirm(client,['101','102'])
    state['user']={**state['user'],'role':'viewer'}
    result=execute(client,get_nonce(confirm.text))
    assert result.status_code==403
    assert not state['requests']


def test_overlap_preflight_aborts_everything(portal):
    mod,client,state,_=portal
    state['overlap_host']='103'
    confirm=request_confirm(client,['101','102','103'])
    result=execute(client,get_nonce(confirm.text))
    assert result.status_code==409
    assert not state['requests']


def test_partial_failure_reports_created_and_skipped(portal):
    mod,client,state,tmp=portal
    state['error_host']='102'
    confirm=request_confirm(client,['101','102','103'])
    result=execute(client,get_nonce(confirm.text))
    assert result.status_code == 200
    assert 'PARTIAL' in result.text and 'SKIPPED' in result.text and 'ERROR' in result.text
    assert len(state['requests'])==1
    with sqlite3.connect(tmp/'demo.sqlite3') as db:
        audit = db.execute('SELECT host_id,outcome FROM audit').fetchall()
    assert audit==[('101','CREATED'),('102','ERROR')]


def test_no_existing_persisted_secrets_in_pending_table(portal):
    mod,client,state,tmp=portal
    confirm=request_confirm(client,['101','102'])
    assert confirm.status_code == 200
    nonce=get_nonce(confirm.text)
    with sqlite3.connect(tmp/'demo.sqlite3') as db:
        saved=db.execute('SELECT nonce_hash,hosts_json FROM mp_batch_pending').fetchone()
    assert saved[0]!=nonce
    assert saved[1]=='["101", "102"]'


def test_index_displays_multiselect_widget(portal):
    mod, client, state, _ = portal
    response = client.get('/')
    assert response.status_code == 200
    assert 'host-multiselect' in response.text
    assert 'Select filtered' in response.text
    assert 'Clear selection' in response.text
    assert response.text.count('name="host_id" value=') == 11


def test_max_host_ids_and_expiry(portal, monkeypatch):
    mod, client, state, db_dir = portal
    import mportal_batch
    with pytest.raises(HTTPException) as exc:
        mportal_batch.normalized_host_ids([str(i) for i in range(1, 50)])
    assert exc.value.status_code == 422
    confirm = request_confirm(client, ['101', '102'])
    assert confirm.status_code == 200
    nonce = get_nonce(confirm.text)
    with sqlite3.connect(db_dir/'demo.sqlite3') as db:
        db.execute('UPDATE mp_batch_pending SET expires_at=0')
    replay = execute(client, nonce)
    assert replay.status_code == 409
    assert not state['requests']
